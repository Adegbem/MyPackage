from MyPackage import MyModule
